﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MiLibreria;

namespace Thanos
{
    public partial class Mantenimiento_Cliente : Mantenimiento
    {
        public Mantenimiento_Cliente()
        {
            InitializeComponent();
        }

        public override Boolean Guardar()
        {
            try
            {
                string cmd = string.Format("EXEC ActualizarClientes '{0}','{1}','{2}'", txtIDCli.Text.Trim(), txtNomCli.Text.Trim(), txtxApellCLi.Text.Trim());
                Utilidades.Ejecutar(cmd);
                MessageBox.Show("Los Datos se han Guardado Correctamente");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error" + error.Message);
                return false;
            }
        }

        public override void Eliminar()
        {
            try
            {
                string cmd = string.Format("EXEC EliminarClientes '{0}'", txtIDCli.Text.Trim());
                Utilidades.Ejecutar(cmd);
                MessageBox.Show("Se ha eliminado Correctamene el articulo ");
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error" + error.Message);
            }
        }


        private void Mantenimiento_Cliente_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtIDCli.Text = "";
            txtNomCli.Text = "";
            txtxApellCLi.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void btnsalir_Click(object sender, EventArgs e)
        {

            admin admin = new admin();
            admin.Hide();
            admin.Show();
        }
    }
}
