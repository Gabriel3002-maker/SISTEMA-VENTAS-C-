﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MiLibreria;

namespace Thanos
{
    public partial class AdministrarFacturas : controlesbasicos
    {
        public AdministrarFacturas()
        {
            InitializeComponent();
        }

        private void AdministrarFacturas_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'administracioinDataSet1.Facturas' Puede moverla o quitarla según sea necesario.
            this.facturasTableAdapter.Fill(this.administracioinDataSet1.Facturas);

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet ds;
                string cmd = " select * from Facturas where FechaFact  LIKE ('%" + textBox1.Text.Trim() + "%')";
                ds = Utilidades.Ejecutar(cmd);
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error" + error.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            admin ad = new admin();
            this.Hide();
            ad.Show();
        }
    }
}
