﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using MiLibreria;
using System.Data;

namespace Thanos
{
    public partial class login : Form_Principal
    {
        public login()
        {
            InitializeComponent();
        }

        //Variable para saber que usario esta conectado
        public static string Codigo = " " ;
        private void button1_Click(object sender, EventArgs e)
        {
            //Conexión
           

            //Obtener usuarios y comprobar
            try
            {
                string cmd = string.Format("Select * from usuarios where account = '{0}' AND password= '{1}'", txtusuario.Text.Trim(), txtcontraseña.Text.Trim());
                DataSet ds = Utilidades.Ejecutar(cmd);

                Codigo = ds.Tables[0].Rows[0]["id_usuario"].ToString().Trim();
                string cuenta = ds.Tables[0].Rows[0]["account"].ToString().Trim();
                string contraseña = ds.Tables[0].Rows[0]["password"].ToString().Trim();

                //Comparar  valores
                if (cuenta == txtusuario.Text.Trim() && contraseña == txtcontraseña.Text.Trim())
                {
                   if(Convert.ToBoolean(ds.Tables[0].Rows[0]["status_admin"]) == true )
                   {
                       admin ventanaadmin = new admin ();
                       this.Hide();
                       ventanaadmin.Show();
                   }
                   else
                   {
                       usuario ventanausuario = new usuario();
                       this.Hide();
                       ventanausuario.Show();
                   }
                }
            }



            catch (Exception error)
            {
                MessageBox.Show("Usuario o contraseña invalidos" + error.Message);
            }
        }

        private void login_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Desea cerrar el programa" , "Aviso" , MessageBoxButtons.YesNo ,MessageBoxIcon.Information);
            Application.Exit();
          
        }

    

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }

    }
}
  
