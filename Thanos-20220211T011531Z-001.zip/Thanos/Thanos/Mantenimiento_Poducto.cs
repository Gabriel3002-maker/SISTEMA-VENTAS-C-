﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MiLibreria;
namespace Thanos
{
    public partial class Mantenimiento_Poducto : Mantenimiento
    {
        public Mantenimiento_Poducto()
        {
            InitializeComponent();
        }

        //Polimorfismo rescrbir metodo
        public override Boolean Guardar()
        {
            try
            {
                string cmd = string.Format("EXEC ActualizarArticulos '{0}','{1}','{2}'", txtIdProduc.Text.Trim(), txtNomProdu.Text.Trim(), txtPrecioProduc.Text.Trim());
                Utilidades.Ejecutar(cmd);
                MessageBox.Show("Se han Guardado el articulo correctamente");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error" + error.Message);
                return false;
            }
        }

        public override void Eliminar()
        {
            try
            {
                string cmd = string.Format("EXEC EliminarArticulos '{0}'" , txtIdProduc.Text.Trim());
                Utilidades.Ejecutar(cmd);
                MessageBox.Show("Se ha eliminado Correctamene el articulo ");
            }
            catch ( Exception error)
            {
                MessageBox.Show("Ha ocurrido un error" + error.Message);
            }
        }

        private void Mantenimiento_Poducto_Load(object sender, EventArgs e)
        {

        }

        private void txtIdProduc_TextChanged(object sender, EventArgs e)
        {
            errorProvider1.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtIdProduc.Text = "";
            txtNomProdu.Text = "";
            txtPrecioProduc.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
          
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
            admin admin = new admin();
            admin.Hide();
            admin.Show();
        }
    }
}
