﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MiLibreria;

namespace Thanos
{
    public partial class usuario : Form_Principal
    {
        public usuario()
        {
            InitializeComponent();
        }

        private void usuario_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void usuario_Load(object sender, EventArgs e)
        {
            string cmd = "Select * from usuarios where id_usuario = " + login.Codigo;
            DataSet DS = Utilidades.Ejecutar(cmd);
            lblUs.Text = DS.Tables[0].Rows[0]["nom_usuarios"].ToString();
            lblCodigo.Text = DS.Tables[0].Rows[0]["id_usuario"].ToString();

          /*  string url = DS.Tables[0].Rows[0]["photo"].ToString();
            pictureBox1.Image = Image.FromFile(url);*/
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ContenedorPrincipal ConP = new ContenedorPrincipal();
            this.Hide();
            ConP.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {

        }
    }
}
