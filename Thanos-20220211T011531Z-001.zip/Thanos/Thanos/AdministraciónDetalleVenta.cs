﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MiLibreria;
namespace Thanos
{
    public partial class AdministraciónDetalleVenta : controlesbasicos
    {
        public AdministraciónDetalleVenta()
        {
            InitializeComponent();
        }

        private void AdministraciónDetalleVenta_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'administracioinDataSet3.articulo' Puede moverla o quitarla según sea necesario.
            this.articuloTableAdapter.Fill(this.administracioinDataSet3.articulo);
            // TODO: esta línea de código carga datos en la tabla 'administracioinDataSet2.detalles' Puede moverla o quitarla según sea necesario.
            this.detallesTableAdapter.Fill(this.administracioinDataSet2.detalles);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            admin ad = new admin();
            ad.Hide();
            ad.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet ds;
                string cmd = " select * from detalles where Num_Factura  like  ('%" + textBox1.Text.Trim() + "%')";
                ds = Utilidades.Ejecutar(cmd);
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error" + error.Message);
            }
        }
    }
}
