﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MiLibreria;

namespace Thanos
{
    public partial class facturación : Procesos
    {
        public facturación()
        {
            InitializeComponent();
        }

        private void facturación_Load(object sender, EventArgs e)
        {
            string cmd = "select * from usuarios where id_usuario =" + login.Codigo;
            DataSet ds;
            ds = Utilidades.Ejecutar(cmd);

            lblatiende.Text = ds.Tables[0].Rows[0]["nom_usuarios"].ToString().Trim();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void errortextbox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void errortextbox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void errortextbox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if( string.IsNullOrEmpty(txtcódigoCLi.Text.Trim()) == false)
            {
                try
                {
                    string cmd = string.Format("Select Nom_Cliente from cliente where id_clientes = '{0}'", txtcódigoCLi.Text.Trim());

                    DataSet ds = Utilidades.Ejecutar(cmd);

                    txtCliente.Text = ds.Tables[0].Rows[0]["Nom_Cliente"].ToString().Trim();
                    txtCodigoPro.Focus();
                }
                catch (Exception error)
                {
                    MessageBox.Show("Ha ocurrido un eror " + error.Message);
                }
                
            }
        }

        private void errortextbox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void errortextbox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void errortextbox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void errortextbox7_TextChanged(object sender, EventArgs e)
        {

        }

        //Variable para Colocar
        public static int cont_fila = 0;
        public static double total;
        private void button1_Click(object sender, EventArgs e)
        {
            if(Utilidades.ValidarFormulario(this, errorProvider1) == false)
            {
                bool existe = false;
                int num_fila = 0;

                //Clomuna este vacia
                if (cont_fila == 0)
                {
                    dataGridView1.Rows.Add(txtCodigoPro.Text, txtDescripProd.Text, txtPreProd.Text, txtCantidPro.Text);
                    double importe = Convert.ToDouble(dataGridView1.Rows[cont_fila].Cells[2].Value) * Convert.ToDouble(dataGridView1.Rows[cont_fila].Cells[3].Value);
                    dataGridView1.Rows[cont_fila].Cells[4].Value = importe;

                    cont_fila++;

                }

                else
                {
                    foreach( DataGridViewRow Fila in dataGridView1.Rows)
                    {
                        if (Fila.Cells[0].Value.ToString() == txtCodigoPro.Text)
                        {
                            existe = true;
                            num_fila = Fila.Index;
                        }
                    }


                    //Actualizar la cantidad
                    if (existe == true)
                    {
                        dataGridView1.Rows[num_fila].Cells[3].Value = (Convert.ToDouble(txtCantidPro.Text) + Convert.ToDouble(dataGridView1.Rows[num_fila].Cells[3].Value)).ToString();
                        double importe = Convert.ToDouble(dataGridView1.Rows[num_fila].Cells[2].Value) * Convert.ToDouble(dataGridView1.Rows[num_fila].Cells[3].Value);

                        dataGridView1.Rows[num_fila].Cells[4].Value = importe;
                    }

                    //
                    else
                    {
                        dataGridView1.Rows.Add(txtCodigoPro.Text, txtDescripProd.Text, txtPreProd.Text, txtCantidPro.Text);
                        double importe = Convert.ToDouble(dataGridView1.Rows[cont_fila].Cells[2].Value) * Convert.ToDouble(dataGridView1.Rows[cont_fila].Cells[3].Value);
                        dataGridView1.Rows[cont_fila].Cells[4].Value = importe;
                        cont_fila++;
                    }
                }

                total = 0;
                foreach (DataGridViewRow Fila in dataGridView1.Rows)
                {
                    total += Convert.ToDouble(Fila.Cells[4].Value);
                }

                txttotal.Text = " $ " + total.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(cont_fila > 0) 
            {
                total = total- (Convert.ToDouble(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[4].Value));
                txttotal.Text = "$" + total.ToString();

                dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);


                cont_fila -- ;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ConsultarClientes ConCli = new ConsultarClientes();
            ConCli.ShowDialog();

            if(ConCli.DialogResult == DialogResult.OK)
            {
                txtcódigoCLi.Text = ConCli.dataGridView1.Rows[ConCli.dataGridView1.CurrentRow.Index].Cells[0].Value.ToString();
                txtCliente.Text = ConCli.dataGridView1.Rows[ConCli.dataGridView1.CurrentRow.Index].Cells[1].Value.ToString();
                txtCodigoPro.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ConsultarProductos ConProduct = new ConsultarProductos();
            ConProduct.ShowDialog();

            if(ConProduct.DialogResult == DialogResult.OK)
            {
                txtCodigoPro.Text = ConProduct.dataGridView1.Rows[ConProduct.dataGridView1.CurrentRow.Index].Cells[0].Value.ToString();
                txtDescripProd.Text = ConProduct.dataGridView1.Rows[ConProduct.dataGridView1.CurrentRow.Index].Cells[1].Value.ToString();
                txtPreProd.Text = ConProduct.dataGridView1.Rows[ConProduct.dataGridView1.CurrentRow.Index].Cells[2].Value.ToString();
                txtCantidPro.Focus();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //Btn Nuevo
            Nuevo();

        }
        public override void Nuevo()
        {
            txtcódigoCLi.Text = "";
            txtCliente.Text = "";
            txtCodigoPro.Text = "";
            txtDescripProd.Text = "";
            txtPreProd.Text = "";
            txtCantidPro.Text = " ";
            txttotal.Text = "$ 0";
            dataGridView1.Rows.Clear();
            cont_fila = 0;
            total = 0;
            txtcódigoCLi.Focus();


        }
        private void button6_Click(object sender, EventArgs e)
        {
            if (cont_fila != 0)
            {
                try
                {
                    string cmd = string.Format("Exec  ActualizarFacturas '{0}'" , txtcódigoCLi.Text.Trim());
                    DataSet ds = Utilidades.Ejecutar(cmd);

                    string NumFact = ds.Tables[0].Rows[0]["NumFact"].ToString().Trim();

                    foreach(DataGridViewRow Fila in dataGridView1.Rows)
                    {
                        cmd = string.Format("Exec ActualizarDetalles  '{0}' , '{1}' , '{2}' , '{3}' " , NumFact , Fila.Cells[0].Value.ToString(), Fila.Cells[2].Value.ToString(), Fila.Cells[3].Value.ToString());
                        ds = Utilidades.Ejecutar(cmd);
                    }

                    cmd = "Exec DatosFactura " + NumFact;
                    ds = Utilidades.Ejecutar(cmd);

                    //Ventana de reportes

               Reportes rp = new Reportes();
                     
                   rp.reportViewer1.LocalReport.DataSources[0].Value = ds.Tables[0];
                    rp.ShowDialog();
                    Nuevo();

                }
                catch (Exception error)
                {
                    MessageBox.Show("Error:" +error.Message);
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtcódigoCLi.Text.Trim()) == false)
            {
                try
                {
                    string cmd = string.Format("Select Nom_Cliente from cliente where id_clientes = '{0}'", txtcódigoCLi.Text.Trim());

                    DataSet ds = Utilidades.Ejecutar(cmd);

                    txtCliente.Text = ds.Tables[0].Rows[0]["Nom_Cliente"].ToString().Trim();
                    txtCodigoPro.Focus();
                }
                catch (Exception error)
                {
                    MessageBox.Show("Ha ocurrido un eror " + error.Message);
                }
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {

            admin admin = new admin();
            admin.Hide();
            admin.Show();
        }
    }
}
