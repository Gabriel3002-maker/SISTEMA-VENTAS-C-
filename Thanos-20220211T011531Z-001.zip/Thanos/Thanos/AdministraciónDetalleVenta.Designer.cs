﻿namespace Thanos
{
    partial class AdministraciónDetalleVenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.detallesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.administracioinDataSet2 = new Thanos.AdministracioinDataSet2();
            this.detallesTableAdapter = new Thanos.AdministracioinDataSet2TableAdapters.detallesTableAdapter();
            this.administracioinDataSet3 = new Thanos.AdministracioinDataSet3();
            this.articuloBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.articuloTableAdapter = new Thanos.AdministracioinDataSet3TableAdapters.articuloTableAdapter();
            this.numFacturaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codProductoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.precioVentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.canVenDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.detallesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.administracioinDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.administracioinDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.articuloBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(44, 15);
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.Text = "Nro Factura:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowDrop = true;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numFacturaDataGridViewTextBoxColumn,
            this.codProductoDataGridViewTextBoxColumn,
            this.precioVentDataGridViewTextBoxColumn,
            this.canVenDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.detallesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(37, 62);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(830, 309);
            this.dataGridView1.TabIndex = 7;
            // 
            // detallesBindingSource
            // 
            this.detallesBindingSource.DataMember = "detalles";
            this.detallesBindingSource.DataSource = this.administracioinDataSet2;
            // 
            // administracioinDataSet2
            // 
            this.administracioinDataSet2.DataSetName = "AdministracioinDataSet2";
            this.administracioinDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // detallesTableAdapter
            // 
            this.detallesTableAdapter.ClearBeforeFill = true;
            // 
            // administracioinDataSet3
            // 
            this.administracioinDataSet3.DataSetName = "AdministracioinDataSet3";
            this.administracioinDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // articuloBindingSource
            // 
            this.articuloBindingSource.DataMember = "articulo";
            this.articuloBindingSource.DataSource = this.administracioinDataSet3;
            // 
            // articuloTableAdapter
            // 
            this.articuloTableAdapter.ClearBeforeFill = true;
            // 
            // numFacturaDataGridViewTextBoxColumn
            // 
            this.numFacturaDataGridViewTextBoxColumn.DataPropertyName = "Num_Factura";
            this.numFacturaDataGridViewTextBoxColumn.HeaderText = "Num_Factura";
            this.numFacturaDataGridViewTextBoxColumn.Name = "numFacturaDataGridViewTextBoxColumn";
            // 
            // codProductoDataGridViewTextBoxColumn
            // 
            this.codProductoDataGridViewTextBoxColumn.DataPropertyName = "CodProducto";
            this.codProductoDataGridViewTextBoxColumn.HeaderText = "CodProducto";
            this.codProductoDataGridViewTextBoxColumn.Name = "codProductoDataGridViewTextBoxColumn";
            // 
            // precioVentDataGridViewTextBoxColumn
            // 
            this.precioVentDataGridViewTextBoxColumn.DataPropertyName = "PrecioVent";
            this.precioVentDataGridViewTextBoxColumn.HeaderText = "PrecioVent";
            this.precioVentDataGridViewTextBoxColumn.Name = "precioVentDataGridViewTextBoxColumn";
            // 
            // canVenDataGridViewTextBoxColumn
            // 
            this.canVenDataGridViewTextBoxColumn.DataPropertyName = "CanVen";
            this.canVenDataGridViewTextBoxColumn.HeaderText = "CanVen";
            this.canVenDataGridViewTextBoxColumn.Name = "canVenDataGridViewTextBoxColumn";
            // 
            // AdministraciónDetalleVenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 406);
            this.Controls.Add(this.dataGridView1);
            this.Name = "AdministraciónDetalleVenta";
            this.Text = "AdministraciónDetalleVenta";
            this.Load += new System.EventHandler(this.AdministraciónDetalleVenta_Load);
            this.Controls.SetChildIndex(this.button1, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.textBox1, 0);
            this.Controls.SetChildIndex(this.pictureBox4, 0);
            this.Controls.SetChildIndex(this.dataGridView1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.detallesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.administracioinDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.administracioinDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.articuloBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private AdministracioinDataSet2 administracioinDataSet2;
        private System.Windows.Forms.BindingSource detallesBindingSource;
        private AdministracioinDataSet2TableAdapters.detallesTableAdapter detallesTableAdapter;
        private AdministracioinDataSet3 administracioinDataSet3;
        private System.Windows.Forms.BindingSource articuloBindingSource;
        private AdministracioinDataSet3TableAdapters.articuloTableAdapter articuloTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn numFacturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codProductoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn precioVentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn canVenDataGridViewTextBoxColumn;
    }
}