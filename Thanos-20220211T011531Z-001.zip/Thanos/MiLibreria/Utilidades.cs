﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace MiLibreria
{
    public class Utilidades
    {
        public static DataSet Ejecutar(string cmd)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-DCRIU3U\\SQLEXPRESS;Initial Catalog=Administracioin;User ID=gabriel;Password=12345");
            con.Open();

            //Almacenar Datos
            DataSet DS = new DataSet();
            SqlDataAdapter DP = new SqlDataAdapter(cmd , con);

            //llenar
            DP.Fill(DS);

            con.Close();

            return DS;


        }

        public static Boolean ValidarFormulario( Control Objeto, ErrorProvider ErroProvider)
        {
            Boolean HayErrores = false;

            foreach( Control Item in Objeto.Controls)
            {
                if (Item is Errortextbox)
                {
                    Errortextbox Obj = (Errortextbox)Item;

                    if (Obj.Validar == true)
                    {
                        if (string.IsNullOrEmpty(Obj.Text.Trim()))
                        {
                            ErroProvider.SetError(Obj, "No puede estar vacio");
                            HayErrores = true;
                        }
                    }

                   if( Obj.SoloNumero == true)
                   {
                       int cont = 0, Letrasencontradas = 0;

                       foreach( char letra in  Obj.Text.Trim())
                       {
                           if(char.IsLetter(Obj.Text.Trim(), cont))
                           {
                               Letrasencontradas++;
                           }
                           cont++;
                       }

                       if(Letrasencontradas != 0)
                       {
                           HayErrores = true;
                           ErroProvider.SetError(Obj, "Solo Numeros");

                       }
                   }
                }
            }

             return HayErrores;
        }
    }
}
